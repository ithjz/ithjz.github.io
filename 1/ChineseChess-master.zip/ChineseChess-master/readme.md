# 中国象棋UI（Javascript离线版）

这是一款为了让理查德.狄克.强输得心服口服，无话可说而开发的中国象棋AI。

## Demo

以下链接使用htmlpreview展示，加载可能会缓慢。

* 人人对战：[人人对战](http://htmlpreview.github.io/?https://raw.githubusercontent.com/JimmyFromSYSU/ChineseChessUI_Javascript/master/UIUI.html)  
* 人机对战：[人机对战](http://htmlpreview.github.io/?https://raw.githubusercontent.com/JimmyFromSYSU/ChineseChessUI_Javascript/master/UIAI.html)  
* 机机对战：[观棋不语](http://htmlpreview.github.io/?https://raw.githubusercontent.com/JimmyFromSYSU/ChineseChessUI_Javascript/master/AIAI.html)
* 残局对战：[一虎下山](http://htmlpreview.github.io/?https://raw.githubusercontent.com/JimmyFromSYSU/ChineseChessUI_Javascript/master/end.html)  

在残局对战中，由AI先手解残局。该残局需要9~10步的棋力才能解开，目前前台AI的棋力只有4步。
