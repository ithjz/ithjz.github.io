﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Threading;


namespace Lianliankan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Bitmap Allmaplist;//图片集
        private int mapheight = 50;//图片边长
        private int size = 10;//大小  个数
        private bool isChoise = false;//是否选中
        private int x1, x2, y1, y2;//选中两个点坐标
        public Point z1, z2;//折点坐标
        private int line = 10, row = 10;//行，列
        private int[] map = new int[12 * 12];//一维数组存地图
        public sbyte flash = new sbyte();//刷新
        private int isend = 25;//消除
        public int a1, a2, b1, b2;//存临时节点坐标
        public sbyte iswin = 0;//是否成功
        public enum LinkType { line0, line1, line2 };
        LinkType linklink = new LinkType();
        // 下载于www.mycodes.net
        private void Form1_Load(object sender, EventArgs e)
        {
            loadgame();//初始化游戏
            this.CenterToScreen();
        }
        private void loadgame()
        {
            flash = 3;

           
            
            this.pictureBox1.Cursor = Cursors.Hand;
            this.pictureBox1.Height=mapheight*(line+2) ;
            this.pictureBox1.Width=mapheight*(row+2);

            //form设置
            this.Height = this.pictureBox1.Height + (this.Height - this.ClientRectangle.Height)
                + this.menuStrip1.Height;
            this.Width = this.pictureBox1.Width + (this.Width - this.ClientRectangle.Width);

            //游戏设计
            maparrang();//游戏排列
            mapview(); //游戏显示
        }
        private void maparrang()
        { 
            Random rad = new Random();
            ArrayList maplist = new ArrayList();
            for (int i = 0; i < (line * row) / 4; i++)
            {
                for (int k = 0; k < 4; k++)
                {
                    maplist.Add(i);
                }
            }
            for (int j = 0; j < (line * row); j++)
            {
                int nIndex = rad.Next() % maplist.Count;
                map[j] = (int)maplist[nIndex];
                maplist.RemoveAt(nIndex);
            }
        }
        private void mapview()
        {
            Graphics g = Mview();
            for (int i = 0; i < (line * row); i++)
            {
               g.DrawImage(getmap(map[i]),mapheight*(i%size)+mapheight,mapheight*(i/size)+mapheight,mapheight,mapheight);
               Pen p = new Pen(Color.Black, 3);
               Rectangle a = new Rectangle((i % size) * mapheight + mapheight, (i / size) * mapheight + mapheight, mapheight - 3, mapheight - 3);
               g.DrawRectangle(p, a);
            }
        }
        private Graphics Mview()
        {
            if (pictureBox1.Image == null)
            {
                Bitmap bmp = new Bitmap(pictureBox1.Height, pictureBox1.Width);
                pictureBox1.Image = bmp;
            }
            Graphics g = Graphics.FromImage(pictureBox1.Image);
            return g;
        }
        private Bitmap getmap(int nu)
        {
            Allmaplist = Lianliankan.Properties.Resources.tp;
            Bitmap igetmap = new Bitmap(mapheight, mapheight);
            Graphics m = Graphics.FromImage(igetmap);
            Rectangle a = new Rectangle(0, 0, mapheight, mapheight);
            Rectangle b = new Rectangle(nu * 64, 0, 64, 64);
            m.DrawImage(Allmaplist, a, b, GraphicsUnit.Pixel);
            return igetmap;
        }



        private void 退出游戏ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void 重新游戏ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Invalidate();
            maparrang();
            mapview();
        }

#region    判断连接

        /// <summary>
        /// 连通判断
        /// X，Y直连
        /// x,y一波折
        /// x,y二波折
        /// </summary>
        /// <returns></returns>



        private bool isconn()
        {
            if (x1 == x2)
            {
                if (Yline(y1, y2, x1) == true)
                {
                    linklink = LinkType.line0;
                    return true;
                }
            }
            if (y1 == y2)
            {
                if (Xline(x1,x2,y1) == true)
                {
                    linklink = LinkType.line0;
                    return true;
                }            
            }
            if (Oneline(x1, y1, x2, y2) == true)
            {
                linklink = LinkType.line1;
                return true;
            }
            if (Twoline(x1, y1, x2, y2) == true)
            {
                linklink = LinkType.line2;
                return true;
            }

                return false;
            
        }
        //x连接
        private bool Xline(int x1, int x2, int y)
        {
            if (x1 > x2)
            {
                int n = x1;
                x1 = x2;
                x2 = n;
            }
            for (int i = x1 + 1; i < x2; i++)
            {
                if (i == x2)
                {
                    break;
                }
                if (map[y * 10 + i] != isend)
                {
                    return false;
                }
            }
            return true;
        }
        //y连接
        private bool Yline(int y1, int y2, int x)
        {
            if (y1 > y2)
            {
                int n = y1;
                y1 = y2;
                y2 = n;
            }
            for (int i = y1+1; i < y2; i++)
            {
                if (i == y2)
                {
                    break;
                }
                if (map[i * 10 + x] != isend)
                {
                    return false;
                }
            }
            return true;
        }
        //一波折
        private bool Oneline(int x1, int y1, int x2, int y2)
        {
            if (y1 < y2)
            {
                if (map[y1 * 10 + x2] == isend)
                {
                    if (Xline(x1, x2, y1))
                    {
                        if (Yline(y1, y2, x2))
                        {
                            z1.X = x2;
                            z1.Y = y1;
                            return true;
                        }
                    }
                }
                if (map[y2 * 10 + x1] == isend)
                {
                    if (Xline(x1, x2, y2))
                    {
                        if (Yline(y1, y2, x1))
                        {
                            z1.X = x1;
                            z1.Y = y2;
                            return true;
                        }
                    }
                }
            }
            else
            {
                if (map[y2 * 10 + x1] == isend)
                {
                    if (Xline(x1, x2, y2))
                    {
                        if (Yline(y1, y2, x1))
                        {
                            z1.X = x1;
                            z1.Y = y2;
                            return true;
                        }
                    }  
                }
                if (map[y1 * 10 + x2] == isend)
                {
                    if (Xline(x1, x2, y1))
                    {
                        if (Yline(y1, y2, x2))
                        {
                            z1.X = x2;
                            z1.Y = y1;
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        //二波折
        //上下左右

        private bool UTwoline(int x1, int y1, int x2, int y2)
        {
            for (int y = 0; y < y1; y++)
            {
                if (Yline(y, y1, x1) == true &&
                    Oneline(x1, y, x2, y2) == true &&
                    map[y * size + x1] == isend)
                {
                    z1.X = x1;
                    z1.Y = y;
                    z2.X = x2;
                    z2.Y = y;
                    return true;
                }
            }
            if (Yline(y1, -1, x1))
            { 
                if(Yline(y2,-1,x2))
                {
                    z1.X=x1;
                    z1.Y=-1;
                    z2.X=x2;
                    z2.Y=-1;
                    return true;
                }
            }
            return false;
        }
        private bool DTwoline(int x1, int y1, int x2, int y2)
        {
            for (int y = y1+1; y <= line; y++)
            {
                if (Yline(y, y1, x1) == true &&
                    Oneline(x1, y, x2, y2) == true &&
                    map[y * size + x1] == isend)
                {
                    z1.X = x1;
                    z1.Y = y;
                    z2.X = x2;
                    z2.Y = y;
                    return true;
                }
            }
            if (Yline(y1, line, x1))
            {
                if (Yline(y1, line, x2))
                {
                    z1.X = x1;
                    z1.Y = line;
                    z2.X = x2;
                    z2.Y = line;
                    return true;
                }
            }
            return false;
        }
        private bool LTwoline(int x1, int y1, int x2, int y2)
        {
            for (int x = 0; x < x1; x++)
            {
                if (Xline(x1, x, y1) == true &&
                  Oneline(x, y1, x2, y2) == true &&
                   map[y1 * size + x] == isend)
                {
                    z1.X = x;
                    z1.Y = y1;
                    z2.X = x;
                    z2.Y = y2;
                    return true;
                }
            }
            if (Xline(x1, -1, y1))
            { 
                if(Xline(x2,-1,y2))
                {
                    z1.X=-1;
                    z1.Y=y1;
                    z2.X=-1;
                    z2.Y=y2;
                    return true;
                }
            }
            return false;
        }
        private bool RTwoline(int x1, int y1, int x2, int y2)
        {
            for (int x = x1+1; x < line; x++)
            {
                if (Xline(x1, x, y1) == true &&
                  Oneline(x, y1, x2, y2) == true &&
                   map[y1 * size + x] == isend)
                {
                    z1.X = x;
                    z1.Y = y1;
                    z2.X = x;
                    z2.Y = y2;
                    return true;
                }
            }
            if (Xline(x2, -1, y2))
            {
                if (Xline(x1, -1, y1))
                {
                    z1.X = line;
                    z1.Y = y1;
                    z2.X = line;
                    z2.Y = y2;
                    return true;
                }
            }
            return false;
        }
        private bool Twoline(int x1, int y1, int x2, int y2)
        {
            try
            {
                if (LTwoline(x1,y1,x2,y2)==true)    
                {
                    return true;
                }
                if (RTwoline(x1,y1,x2,y2)==true)
                {
                    return true;
                }
                if (UTwoline(x1,y1,x2,y2)==true)
                {
                    return true;
                }
                if (DTwoline(x1,y1,x2,y2)==true)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "warring:", MessageBoxButtons.OK, MessageBoxIcon.Information);   
                //throw;
            }
            return false;
        }
#endregion

#region 画框/线  判断相同  胜利  消除

        private void painFrame(int x,int y,Color co,string linekind)
        {
            Graphics g = this.pictureBox1.CreateGraphics();
            Pen p = new Pen(co, 2);
            if (linekind == "虚线")
            {
                p.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            }
            Rectangle a = new Rectangle(x * mapheight - 1 + mapheight, y * mapheight - 1 + mapheight, mapheight - 2, mapheight - 2);
            g.DrawRectangle(p, a);
        }
       
        private void painLine(int x1, int y1, int x2, int y2, Color co, LinkType l)
        {
            Graphics g = this.pictureBox1.CreateGraphics();
            Pen p = new Pen(co, 2);

            int x_1 = (x1 + 1) * mapheight + mapheight / 2;
            int y_1 = (y1 + 1) * mapheight + mapheight / 2;
            int x_2 = (x2 + 1) * mapheight + mapheight / 2;
            int y_2 = (y2 + 1) * mapheight + mapheight / 2;
            int z1x = (z1.X + 1) * mapheight + mapheight / 2;
            int z1y = (z1.Y + 1) * mapheight + mapheight / 2;
            int z2x = (z2.X + 1) * mapheight + mapheight / 2;
            int z2y = (z2.Y + 1) * mapheight + mapheight / 2;

            switch (l)
            { 
                case LinkType.line0:
                    g.DrawLine(p, x_1, y_1, x_2, y_2);
                    break;
                case LinkType.line1:
                    g.DrawLine(p, x_1, y_1, z1x, z1y);
                    g.DrawLine(p, z1x, z1y, x_2, y_2);
                    break;
                case LinkType.line2:
                    g.DrawLine(p, x_1, y_1, z1x, z1y); 
                    g.DrawLine(p, z1x, z1y, z2x, z2y);
                    g.DrawLine(p, z2x, z2y, x_2, y_2);
                    break;
                default :
                    break;
            }
        }

        private bool issame(int x1, int y1, int x2, int y2)
        {
            if (map[y1*line+x1].Equals(map[y2*line+x2]))
            {
                return true;   
            }
            else
            {
                return false;
            }
        }

        private void isWin()
        {
            if (iswin.Equals(50))
            {
                Form2 f2 = new Form2();
                f2.ShowDialog();
            }
        }

        private void clearmap(int x,int y)
        {
            Graphics g = this.pictureBox1.CreateGraphics();
            SolidBrush b = new SolidBrush(Color.Black);
            Rectangle Frame = new Rectangle(x * mapheight + mapheight, y * mapheight + mapheight, mapheight, mapheight);
            g.FillRectangle(b, Frame);
        }
        #endregion



#region  鼠标事件

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            int x, y;
            if (e.Button==MouseButtons.Left)
            {
                painFrame(a1, b1, Color.Black, "实线");
                painFrame(a2, b2, Color.Black, "实线");
                x = (e.X - mapheight) / mapheight;
                y = (e.Y - mapheight) / mapheight;
                if (e.X <= 50 || e.X >= 550 || e.Y <= 50 || e.Y >= 550)
                {
                    return;
                }
                if (map[y*line+x]==isend)
                {
                    return;
                }
                if (isChoise==false)
                {
                    x1 = x;
                    y1 = y;
                    painFrame(x1, y1, Color.White, "实线");
                    isChoise = !isChoise;
                }
                if (isChoise == true)
                {
                    x2 = x;
                    y2 = y;
                    if (x1 == x2 && y1 == y2)
                    {
                        return;
                    }
                    painFrame(x2, y2, Color.White, "实线");
                    if (x1 > x2)
                    {
                        int n = x1;
                        x1 = x2;
                        x2 = n;
                        n = y1;
                        y1 = y2;
                        y2 = n;
                    }
                    if (issame(x1, y1, x2, y2) == true && isconn() == true)
                    {
                        painLine(x1, y1, x2, y2, Color.White, linklink);
                        Thread.Sleep(500);
                        clearmap(x1, y1);
                        clearmap(x2, y2);
                        painLine(x1, y1, x2, y2, Color.Black, linklink);
                        painFrame(x1, y1, Color.Black, "实线");
                        painFrame(x2, y2, Color.Black, "实线");
                        map[y1 * line + x1] = isend;
                        map[y2 * line + x2] = isend;
                        mapview();
                        isChoise = !isChoise;
                        iswin += 1;
                        isWin();
                        label1.Text = "已消除成功" + iswin + "对";
                        this.label2.Text = x1.ToString() + y1.ToString() + x2.ToString() + y2.ToString() + z1.X.ToString() + z1.Y.ToString() + z2.X.ToString() + z2.Y.ToString();
                    }
                    else
                    {
                        isChoise = false;
                        painFrame(x1, y1, Color.Black, "实线");
                        painFrame(x2, y2, Color.Black, "实线");
                        return;
                    
                    }
                }
            }
        }

        #endregion

        
#region  重排   电脑查找 
        private bool computerfind()
        {
            for (int i = 1; i < 100; i++)
            {
                if (map[i] == isend) continue;
               // int j = 1;
                for (int  j = i+1; j < 100; j++)
                {
                    //if (map[j] == isend) continue;
                    if (map[i].Equals(map[j]))
                    {
                        x1 = i % 10;
                        y1 = i / 10;
                        x2 = j % 10;
                        y2 = j / 10;
                        if (isconn())
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }


        private void 电脑查找ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            painFrame(x1, y1, Color.Black, "实线");
            if (computerfind())
            {
                painFrame(x2, y2, Color.White, "虚线");
                painFrame(x1, y1, Color.White, "虚线");
                a1 = x1;
                a2 = y1;
                b1 = x2;
                b2 = y2;
            }
            
        } 

        private void 调整布局ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                flash--;
                if (false.Equals(1))
                {
                    调整布局ToolStripMenuItem.Enabled = false;
                }
                else
                {
                    pictureBox1.Invalidate();
                    Random r = new Random();
                    ArrayList l = new ArrayList();
                    for (sbyte i = 0; i < (line * row); i++)
                    {
                        l.Add(map[i]);
                    }
                    for (sbyte j = 0; j < (line * row); j++)
                    {
                        int chang = r.Next() % l.Count;
                        int a = map[j];
                        map[j] = map[chang];
                        map[chang] = a;
                    }
                    mapview();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "warring", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

#endregion




    }
}
