﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Lianliankan
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        // 下载于www.mycodes.net
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
