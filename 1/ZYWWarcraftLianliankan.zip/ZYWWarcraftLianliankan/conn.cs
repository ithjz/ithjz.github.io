﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lianliankan
{
    class conn
    {
     //   private int x1, x2, y1, y2;//选中两个点坐标
       // public Point z1, z2;//折点坐标
        // 下载于www.mycodes.net
    }
}
